// script.js
const quotes = [
  "Practice makes perfect.",
  "Typing is fun and useful.",
  "Improve your speed daily.",
  "Stay focused and keep learning."
];

let timer = document.getElementById("timer");
let quoteDisplay = document.getElementById("quote-display");
let quoteInput = document.getElementById("quote-input");
let wpmDisplay = document.getElementById("wpm");
let accuracyDisplay = document.getElementById("accuracy");

let startTime, timerInterval;
let currentQuote = "";

function getRandomQuote() {
  return quotes[Math.floor(Math.random() * quotes.length)];
}

function startTest() {
  currentQuote = getRandomQuote();
  quoteDisplay.textContent = currentQuote;
  quoteInput.value = "";
  quoteInput.disabled = false;
  quoteInput.focus();
  startTime = new Date();
  clearInterval(timerInterval);
  timerInterval = setInterval(updateTimer, 1000);
}

function updateTimer() {
  let timeElapsed = Math.floor((new Date() - startTime) / 1000);
  timer.textContent = timeElapsed;

  // WPM & Accuracy Calculation
  let typed = quoteInput.value;
  let wordsTyped = typed.trim().split(/\s+/).length;
  let wpm = Math.round((wordsTyped / timeElapsed) * 60);
  wpmDisplay.textContent = isNaN(wpm) ? 0 : wpm;

  let correctChars = 0;
  for (let i = 0; i < typed.length; i++) {
    if (typed[i] === currentQuote[i]) correctChars++;
  }
  let accuracy = Math.round((correctChars / typed.length) * 100);
  accuracyDisplay.textContent = isNaN(accuracy) ? "100%" : `${accuracy}%`;

  if (typed === currentQuote) {
    clearInterval(timerInterval);
    quoteInput.disabled = true;
  }
}

// Start initial test
startTest();
